// DeepSeek Exporter - Background Script
// 处理扩展安装后的重定向

chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason === 'install') {
        // 首次安装时打开欢迎页面
        chrome.tabs.create({
            url: 'https://ds.aikeyu.cn/?from=chrome_extension&installed=1'
        });
    } else if (details.reason === 'update') {
        // 更新时可以选择是否打开更新日志页面
        // chrome.tabs.create({
        //   url: 'https://ds.aikeyu.cn/?from=chrome_extension&updated=1'
        // });
    }
});
